Jongware's pngdefry tool for deconverting iPhone-optimized PNG images.  The
original source plus lots more information can be found here:
http://www.jongware.com/pngdefry.html .

To compile:

    $ ./configure [--prefix=PATH]
    $ make

To install:

    $ sudo make install
